﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

    Vector3 initialPos;

    public float speed = 3;
    public float rangeY = 2;
    int direction = 1;

	// Use this for initialization
	void Start () {
        initialPos = transform.position;
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        float movementY = speed * Time.deltaTime * direction;

        if (direction == -1) {
            movementY *= 1.2f;
        }

        float newY = transform.position.y + movementY;

        if (Mathf.Abs(newY - initialPos.y) > rangeY) {
            direction *= -1;
        }

        else
        {
            transform.position += new Vector3(0, movementY, 0);
        }
    }
}
