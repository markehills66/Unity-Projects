﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOverManager : MonoBehaviour {

    public Text scoreText;

    public Text highScoreText;

	// Use this for initialization
	void Start () {
        scoreText.text = "Score: " + GameManager.instance.score.ToString();
        highScoreText.text = "Highscore: " + GameManager.instance.highScore.ToString();
    }

    public void RestartGame() {
        SceneManager.LoadScene("Level 1");
        GameManager.instance.ResetGame();
    }
}
