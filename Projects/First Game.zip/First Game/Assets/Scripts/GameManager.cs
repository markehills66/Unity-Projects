﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    public int score = 0;
    public int highScore = 0;
    public int currentLevel = 1;
    public int highestLevel = 2;
    HudManager hudManager;

    public static GameManager instance;

    void Awake() {
        if (instance == null) {
            instance = this;
        }
        else if(instance != this) {
            Destroy(gameObject);
        }

        DontDestroyOnLoad(gameObject);
    }

    void Update() {
        if (Input.GetKey("escape")) {
            Application.Quit();
        }
    }

    public void IncreaseScore(int amount) {
        hudManager = FindObjectOfType<HudManager>();
        score += amount;
        if (score > highScore) {
            highScore = score;
        }
        hudManager.ResetHud();
        
    }

    public void ResetGame() {
        hudManager = FindObjectOfType<HudManager>();
        score = 0;
        currentLevel = 1;
        SceneManager.LoadScene("Level 1");
        hudManager.ResetHud();
    }

    public void IncreaseLevel()
    {
        if (currentLevel < highestLevel)
        {
            currentLevel++;

        }
        else {
            currentLevel = 1;
        }
        SceneManager.LoadScene("Level " + currentLevel);
    }

    public void GameOver() {
        SceneManager.LoadScene("Game Over");
    }
}