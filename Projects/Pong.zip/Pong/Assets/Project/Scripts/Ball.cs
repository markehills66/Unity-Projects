﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {

    public float speed = 1f;

    private Rigidbody2D ballBody;

    // Use this for initialization
    void Start () {
        ballBody = GetComponent<Rigidbody2D>();
        ballBody.velocity = new Vector2(0, 0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Limit")
        {

            if (collision.transform.position.y > this.transform.position.y && ballBody.velocity.y > 0)
            {
                ballBody.velocity = new Vector2(ballBody.velocity.x, -ballBody.velocity.y);
            }

            if (collision.transform.position.y < this.transform.position.y && ballBody.velocity.y < 0)
            {
                ballBody.velocity = new Vector2(ballBody.velocity.x, -ballBody.velocity.y);
            }
        }
        else if(collision.tag == "Paddle"){
            ballBody.velocity = new Vector2(-ballBody.velocity.x, ballBody.velocity.y);
        }
}
